import prompt
import brain_games.cli
brain_games.cli.welcome_user()