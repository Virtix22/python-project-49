#!/usr/bin/env python3

from brain_games.games.brain_progression_body import progression_start


def main():
    progression_start()


if __name__ == '__main__':
    main()
