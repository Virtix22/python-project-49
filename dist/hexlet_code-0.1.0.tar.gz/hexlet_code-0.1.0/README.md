## Hexlet tests and linter status:
[![Actions Status](https://github.com/Virtix22/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Virtix22/python-project-49/actions)

### CodeClimate
<a href="https://codeclimate.com/github/Virtix22/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/03366cd0be3678852903/maintainability" /></a>

### Aciinema for brain-even (step 5)
<a href="https://asciinema.org/a/Dfg5ZFJZKKaRQwRN8IWR8MGGs" target="_blank"><img src="https://asciinema.org/a/Dfg5ZFJZKKaRQwRN8IWR8MGGs.svg" /></a>
