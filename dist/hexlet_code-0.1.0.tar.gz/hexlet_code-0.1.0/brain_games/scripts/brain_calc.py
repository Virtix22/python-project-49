#!/usr/bin/env python3

from brain_games.games.brain_calc_body import calc_start


def main():
    calc_start()


if __name__ == '__main__':
    main()
